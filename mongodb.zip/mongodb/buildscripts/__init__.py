
import os;

def findHacks( un ):
    return None
